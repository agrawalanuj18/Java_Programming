package codewithharry.gym;

public class HarryNew {
    public static void main(String[] args) {
        System.out.println("I am new class in harry gym's!");
    }
}
